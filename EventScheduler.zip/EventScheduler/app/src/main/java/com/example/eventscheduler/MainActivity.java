package com.example.eventscheduler;
import org.json.JSONException;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.os.Message;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.SharedPreferences;
import android.graphics.Bitmap;


public class MainActivity extends ActionBarActivity {
	private Button Click;
    private Button Calendar;
	private WebView webview;
	private Obj_OAuth oauth;
    public static String calendarid;


    public static String str;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Click = (Button) findViewById(R.id.btnClick);
        Calendar = (Button) findViewById(R.id.btnCalendar);
        oauth = new Obj_OAuth();
        webview = (WebView) findViewById(R.id.webView2);
		webview.setWebViewClient(new MyWebViewClient());
		webview.getSettings().setJavaScriptEnabled(true);
       final EditText text = (EditText)findViewById(R.id.EditText01);



        Click.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				//setContentView(R.layout.activity_main);
				if (checkNetwork()){
					new ObjWeb().execute("");
					
				}
			}
		});

        Calendar.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                //setContentView(R.layout.activity_main);

                calendarid = text.getText().toString();
                System.out.println("String: "+calendarid);
            }
        });
    }



    public boolean checkNetwork() {
		System.out.println("\t\t ******* Check Intenet Connection ********");

		ConnectivityManager connMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();

		if (networkInfo != null && networkInfo.isConnected()) {
			// fetch data
			System.out.println("\t\t ******* Is Connected ********");
			return true;

		} else {
			// display error
			System.out.println("\t\t ******* Error Connection ********");
			return false;
		}
	}//End Method checkNetwork

    private void myMethod()
    {
         // Assigning a value;
        getVariable();
    }

    public static String getVariable()
    {
        System.out.println("String again: "+calendarid);
        return calendarid;
    }
    
    private class ObjWeb extends AsyncTask<String, Void, String> {

		@Override
		protected String doInBackground(String... params) {		
			oauth.oauth_choreo();
			return null;
		}

		@Override
		protected void onPostExecute(String result) {
			
			//setContentView(R.layout.auth_view);
			webview.loadUrl(oauth.getAuthorizationURL());
			new ObjToken().execute("");



			
		}
	
	}// end of class ObjWeb
    
    private class ObjToken extends AsyncTask<String, Void, String> {

		@Override
		protected String doInBackground(String... params) {

			
			oauth.oauth_finalize();
			return null;
			
		}

		@Override
		protected void onPostExecute(String result) {
			//System.out.println("\t **********  10   *************");
			//lbOne.setText("Token is : " + oauth.getAccessToken());
			//lbOne1.setText("Finished Initial OAuth");
			new ObjGetReading().execute("");
			//lbOne.setText(oauth.getMetricsResultJSON());
		}
	}//end of class ObjToken
    
    private class ObjGetReading extends AsyncTask<String, Void, String>{

		@Override
		protected String doInBackground(String... params) {
			
			
			oauth.createevent();
			
			return null;
		}
		@Override
		protected void onPostExecute(String result) {
			
			try {
				
			} catch (Exception e) {
				e.printStackTrace();
			}


		}
	}




    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    
    
    
    public class MyWebViewClient extends WebViewClient {

		public MyWebViewClient() {
			super();
			// start anything you need to
		}

		public void onPageStarted(WebView view, String url, Bitmap favicon) {
			// Do something to the urls, views, etc.
		}

	}// end of MyWebViewClient
}

