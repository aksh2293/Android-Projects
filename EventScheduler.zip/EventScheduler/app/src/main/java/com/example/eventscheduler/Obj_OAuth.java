package com.example.eventscheduler;

import com.temboo.Library.Google.Calendar.*;
import com.temboo.Library.Google.OAuth.InitializeOAuth;
import com.temboo.Library.Google.OAuth.FinalizeOAuth;
import com.temboo.Library.Google.OAuth.InitializeOAuth.InitializeOAuthInputSet;
import com.temboo.Library.Google.OAuth.InitializeOAuth.InitializeOAuthResultSet;
import com.temboo.Library.Google.OAuth.FinalizeOAuth.FinalizeOAuthInputSet;
import com.temboo.Library.Google.OAuth.FinalizeOAuth.FinalizeOAuthResultSet;
import com.temboo.Library.Google.Calendar.CreateEvent;
import com.temboo.Library.Google.Calendar.CreateEvent.CreateEventInputSet;
import com.temboo.Library.Google.Calendar.CreateEvent.CreateEventResultSet;
import com.temboo.Library.Google.Calendar.GetAllCalendars.GetAllCalendarsInputSet;
import com.temboo.Library.Google.Calendar.GetAllCalendars.GetAllCalendarsResultSet;
import com.temboo.core.TembooException;
import com.temboo.core.TembooSession;
import java.io.IOException;
import java.io.InputStreamReader;
import android.util.Log;

public class Obj_OAuth {
	private TembooSession session;
	//initialize OAuth
	private InitializeOAuth initializeOAuthChoreo;
	private InitializeOAuthInputSet initializeOAuthInputs;
	private InitializeOAuthResultSet initializeOAuthResults;

	//finalize OAuth
	private FinalizeOAuth finalizeOAuthChoreo;
	private FinalizeOAuthInputSet finalizeOAuthInputs;
	private FinalizeOAuthResultSet finalizeOAuthResults;
	
	private final String CLIENTID = "96441163057-1n3u1fcic6qdktfk29lv42u3avkd1hv2.apps.googleusercontent.com";
	private final String CLIENTSECRET = "dcwOUue0GTpDvLYQWt_6gjA6";
	private final String SCOPE="https://www.googleapis.com/auth/calendar";
	public static String CALENDARID = MainActivity.str;


	private String AuthorizationURL = "111";
	private String CallBackID = "222";
	private String AccessToken = "444";
	private String expires="22";
	private String RefreshToken = "100";


	private CreateEvent createEventChoreo;
	private CreateEventInputSet createEventInputs ;
	private CreateEventResultSet createEventResults;
			
	public Obj_OAuth(){}

	public void oauth_choreo() {
		// Instantiate the Choreo, using a previously instantiated TembooSession

		try {
			//The session values are given by the temboo website after 
			// making a user and signing up
			session = new TembooSession("akshayaiyer", "myFirstApp", "b24d3213f4f74ad8ad9ae51894e4e9b6");
			
			initializeOAuthChoreo = new InitializeOAuth(session);

			
			// Get an InputSet object for the choreo
			initializeOAuthInputs = initializeOAuthChoreo.newInputSet();

			// Set inputs
			initializeOAuthInputs.set_ClientID(CLIENTID);
			initializeOAuthInputs.set_Scope(SCOPE);
			 

			// Execute Choreo
			initializeOAuthResults = initializeOAuthChoreo.execute(initializeOAuthInputs);

			AuthorizationURL = initializeOAuthResults.get_AuthorizationURL();
			CallBackID = initializeOAuthResults.get_CallbackID();
			

			System.out.println("---------------5-----------------"); //for debugging

		} catch (TembooException e) {
			e.printStackTrace();
		}
	}
	
	public void oauth_finalize() {
		try {
			session = new TembooSession("akshayaiyer", "myFirstApp", "b24d3213f4f74ad8ad9ae51894e4e9b6");
			
			finalizeOAuthChoreo = new FinalizeOAuth(session);

			// Get an InputSet object for the choreo
			finalizeOAuthInputs = finalizeOAuthChoreo.newInputSet();

			// Set inputs
			finalizeOAuthInputs.set_ClientID(CLIENTID);
			finalizeOAuthInputs.set_ClientSecret(CLIENTSECRET);
			finalizeOAuthInputs.set_CallbackID(CallBackID);
			
			
			
			// Execute Choreo
			finalizeOAuthResults = finalizeOAuthChoreo.execute(finalizeOAuthInputs);
			
			//getSpo2();

			System.out.println("---------------6----------------"); //for debugging

			AccessToken = finalizeOAuthResults.get_AccessToken();
			expires = finalizeOAuthResults.get_Expires();
			RefreshToken = finalizeOAuthResults.get_RefreshToken();
			
			
			
						
						
						
		} catch (TembooException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	
	public void createevent(){
		CreateEvent createEventChoreo = new CreateEvent(session);
		// Get an InputSet object for the choreo
		CreateEventInputSet createEventInputs = createEventChoreo.newInputSet();
		
		createEventInputs.set_ClientID(CLIENTID);
		createEventInputs.set_ClientSecret(CLIENTSECRET);
		createEventInputs.set_RefreshToken(RefreshToken);
		createEventInputs.set_CalendarID(MainActivity.calendarid);
		createEventInputs.set_EndDate("2015-04-14");
		createEventInputs.set_EndTime("10:30:00");
		createEventInputs.set_EventTitle("Calendar test");
		createEventInputs.set_StartDate("2015-04-14");
		createEventInputs.set_StartTime("10:00:00");

		
		// Execute Choreo
		try {
			CreateEventResultSet createEventResults = createEventChoreo.execute(createEventInputs);
		} catch (TembooException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public String getCLIENTID() {
		return CLIENTID;
	}

	public String getCLIENTSECRET() {
		return CLIENTSECRET;
	}
	
	public String getAuthorizationURL() {
		return AuthorizationURL;
	}

	public void setAuthorizationURL(String authorizationURL) {
		AuthorizationURL = authorizationURL;
	}

	public String getCallBackID() {
		return CallBackID;
	}

	public void setCallBackID(String callBackID) {
		CallBackID = callBackID;
	}
	
	public String getAccessToken() {
		return AccessToken;
	}
	
	public void setAccessToken(String accessToken) {
		AccessToken = accessToken;
	}
	
	public String getRefreshToken() {
		return RefreshToken;
	}
	
	public void setRefreshToken(String refreshToken) {
		RefreshToken = refreshToken;
	}
	
	
	

}
